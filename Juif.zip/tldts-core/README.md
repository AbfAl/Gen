# `tldts-core`

> core building blocks of tldts, used by both `tldts` and `tldts-experimental` packages.
