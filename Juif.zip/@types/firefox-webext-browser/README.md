# Installation
> `npm install --save @types/firefox-webext-browser`

# Summary
This package contains type definitions for WebExtension Development in FireFox (https://developer.mozilla.org/en-US/Add-ons/WebExtensions).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/firefox-webext-browser.

### Additional Details
 * Last updated: Thu, 08 Jul 2021 12:01:38 GMT
 * Dependencies: none
 * Global values: `browser`

# Credits
These definitions were written by [Jasmin Bom](https://github.com/jsmnbom).
