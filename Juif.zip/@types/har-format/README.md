# Installation
> `npm install --save @types/har-format`

# Summary
This package contains type definitions for HAR (https://w3c.github.io/web-performance/specs/HAR/Overview.html).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/har-format.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 20:33:13 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Michael Mrowetz](https://github.com/micmro), and [Marcell Toth](https://github.com/marcelltoth).
