# Installation
> `npm install --save @types/filesystem`

# Summary
This package contains type definitions for File System API (http://www.w3.org/TR/file-system-api/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/filesystem.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 20:32:58 GMT
 * Dependencies: [@types/filewriter](https://npmjs.com/package/@types/filewriter)
 * Global values: none

# Credits
These definitions were written by [Kon](http://phyzkit.net/).
