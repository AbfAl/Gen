# Installation
> `npm install --save @types/filewriter`

# Summary
This package contains type definitions for File API: Writer (http://www.w3.org/TR/file-writer-api/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/filewriter.

### Additional Details
 * Last updated: Thu, 25 Mar 2021 17:31:23 GMT
 * Dependencies: none
 * Global values: `FileSaver`

# Credits
These definitions were written by [Kon](http://phyzkit.net/).
