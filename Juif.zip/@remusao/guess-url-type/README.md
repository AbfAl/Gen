# `@remusao/guess-url-type`

> Guess type of resource based on its URL
