# v1.4.1 (Tue Nov 03 2020)

#### :nut_and_bolt: Dependencies

- Bump typescript from 3.9.7 to 4.0.2 [#257](https://github.com/remusao/mono/pull/257) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- Bump @types/mocha from 7.0.2 to 8.0.0 [#218](https://github.com/remusao/mono/pull/218) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.4.0 (Sun Jun 14 2020)

#### :nut_and_bolt: Dependencies

- Bump mocha from 7.2.0 to 8.0.1 [#195](https://github.com/remusao/mono/pull/195) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.3.0 (Wed Feb 12 2020)

#### :running_woman: Performance

- Use Map instead of array for trie to lower memory usage [#21](https://github.com/remusao/mono/pull/21) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.2.1 (Mon Feb 03 2020)

#### :bug: Bug Fix

- Add types entry in package.json [#11](https://github.com/remusao/mono/pull/11) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.2.0 (Mon Feb 03 2020)

#### :house: Internal

- Use chai and mocha instead of jest for testing [#9](https://github.com/remusao/mono/pull/9) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.1.0 (Sat Feb 01 2020)

#### :rocket: New Feature

- feat: add new auto-config package [#2](https://github.com/remusao/mono/pull/2) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.0.1 (Sat Feb 01 2020)

#### :bug: Bug Fix

- fix: add dist folder to gitignore  ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))