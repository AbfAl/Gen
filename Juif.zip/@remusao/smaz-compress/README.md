# `@remusao/smaz-compress`

> Compress strings using custom codebooks
