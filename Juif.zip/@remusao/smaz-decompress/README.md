# `@remusao/smaz-decompress`

> Decompress strings using custom codebooks
